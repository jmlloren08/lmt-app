<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => Hash::make('password123'),
            'roles' => 'administrator',
        ]);

        // Create division leader user
        User::create([
            'name' => 'Division Leader',
            'email' => 'division@example.com',
            'password' => Hash::make('password123'),
            'roles' => 'division_leader',
        ]);

        // Create test user without role
        User::create([
            'name' => 'Test User',
            'email' => 'test@example.com',
            'password' => Hash::make('password123'),
            'roles' => null,
        ]);

        // Create another test user without role
        User::create([
            'name' => 'Another Test User',
            'email' => 'test2@example.com',
            'password' => Hash::make('password123'),
            'roles' => null,
        ]);
    }
}
